import StartScene from './scenes/StartScene.js';
import CenaIntro from './scenes/CenaIntro.js';
import MundoNormal from './scenes/MundoNormalScene.js';
import InstructionsScene from './scenes/InstructionsScene.js';
import CreditsScene from './scenes/CreditsScene.js';

const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,

  scene: [StartScene, CenaIntro, MundoNormal, InstructionsScene, CreditsScene],

  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 600 },
      debug: false
    }
  }
};

const game = new Phaser.Game(config);
