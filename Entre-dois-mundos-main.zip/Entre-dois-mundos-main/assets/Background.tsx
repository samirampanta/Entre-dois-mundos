<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Background" tilewidth="16" tileheight="16" tilecount="2842" columns="58">
 <image source="Free Pixel Art Forest/Free Pixel Art Forest/Preview/Background.png" width="928" height="793"/>
</tileset>
