<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="AllSprites" tilewidth="16" tileheight="16" tilecount="57600" columns="320">
 <image source="AllSprites.png" width="5120" height="2880"/>
</tileset>
