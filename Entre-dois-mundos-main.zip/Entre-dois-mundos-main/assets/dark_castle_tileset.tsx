<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="dark_castle_tileset" tilewidth="16" tileheight="16" tilecount="242" columns="22">
 <image source="dark_castle_tileset.png" width="358" height="179"/>
</tileset>
